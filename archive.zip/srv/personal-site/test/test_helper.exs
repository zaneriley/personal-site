{:ok, _} = Application.ensure_all_started(:portfolio)

ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Portfolio.Repo, :manual)
